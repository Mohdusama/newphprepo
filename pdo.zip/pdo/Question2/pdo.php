<?php

//var_dump(PDO::getAvailableDrivers());


try {

$conn = new PDO('mysql:host=127.0.0.1;dbname=bootcamp','debian-sys-maint','ibxF9SxkWKCDpplr');
//$dataa= $con->query("SELECT * FROM emp")->fetchAll();
//var_dump($dataa);

//die;

//$prepare = $con->prepare("select * from emp where name = :type");
//if($prepare->execute(['name' =>'usama' ]))
/*{
$dataa = $prepare->fetchAll(PDO::FETCH_ASSOC);
var_dump($dataa);
}
$con=null;
 
*/

}

catch(PDOException $ex)
{
die('Eroor : ' .$ex);

} 






?>
