<?php
$fname = $_POST['fname'];
$lname = $_POST['lname'];
$email = $_POST['email'];
$contact = $_POST['con'];
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
  $emailErr = "Invalid email format";
  //echo $emailErr;
  exit($emailErr);

}

try {

    // $sql = "INSERT INTO form (fname, lname, email,contact) 
    // VALUES ('John2', 'Doe2', 'john2@example.com',9260407448)";
    // // use exec() because no results are returned
    // $conn->exec($sql);
    // echo "New record created successfully";
     $con = new PDO('mysql:host=127.0.0.1;dbname=bootcamp','debian-sys-maint','ibxF9SxkWKCDpplr');
     var_dump($con);
    $sql1 =$con->exec("INSERT INTO Emp_data (first_name,last_name,email,mobile) values ('$fname','$lname','$email',$contact)");
    //$stmt = $con->query($sql);
 //   $stmt->bindParam(':first_name',$fname);
   // $stmt->bindParam(':last_name',$lname);
   // $stmt->bindParam(':email',$email);
   // $stmt->bindParam(':mobile',$contact);
    // $fname = "raman";
    // $lname = "dhaliwal";
    // $email = "raman@example.com";
    // $contact="988845233";
      // $stmt->execute();
    echo "records added";
    }
catch(PDOException $e)
    {
    echo "Connection failed: " . $e->getMessage();
    }

    $con = null;
?>
